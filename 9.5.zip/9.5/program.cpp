#include "splashkit.h"
#include <sstream>
#include <string>
#include <iostream>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include "program.h"
using namespace std;

class TextRPG{
private:
    struct Player_data {
        int health;
        int mana;
    }player;

    gameSection game_section = MENU;
    OrcFight orcFight = NONE_ACTION;
    HealthPuzzle healthPuzzle = NONE_ACTION_HEALTH;
    ManaPuzzle manaPuzzle = NONE_ACTION_MANA;
    SkeletonLich skeletonLich = BEFORE_ACTION;
    RiddleQ1 riddleQ1 = NO_ANSWER;
    RiddleQ2 riddleQ2 = NO_ANSWER2;
    bool tookDamage = false;
    bool usedMana = false;
    bool gotHealth = false;
    bool gotMana = false;

    unordered_map<gameSection, vector<gameSection>> graph;
    map<gameSection, pair<int, int>> position;
    map<gameSection, string> name;
    set<gameSection> visitedSection; 

    void gameGraph(){
        // rules for each section
        graph[MENU] = {SECTION1, SECTION2, SECTION3, SECTION4};
        graph[SECTION1] = {MENU, FAILED, FIGHTING_ORC1};
        graph[SECTION2] = {MENU, RETURNING_H, SOLVE_HPUZZLE, BOSS_SECTION};
        graph[SECTION3] = {MENU, RETURNING_M, SOLVE_MPUZZLE, BOSS_SECTION};
        graph[BOSS_SECTION] = {FIRST_HIT, BOSS_KILL};
        graph[SECTION4] = {MENU, RETURNING_R, SOLVE_RIDDLE, SOLVE_RIDDLE2, BOSS_SECTION};

        // position for the nodes
        position[MENU] = {400, 100};
        position[SECTION1] = {100, 200};
        position[FAILED] = {50, 300};
        position[FIGHTING_ORC1] = {150, 300};
        position[SECTION2] = {300, 200};
        position[RETURNING_H] = {250, 300};
        position[SOLVE_HPUZZLE] = {350, 300};
        position[SECTION3] = {500, 200};
        position[RETURNING_M] = {450, 300};
        position[SOLVE_MPUZZLE] = {550, 300};
        position[BOSS_SECTION] = {300, 400};
        position[FIRST_HIT] = {250, 500};
        position[BOSS_KILL] = {350, 500};
        position[SECTION4] = {700, 200};
        position[RETURNING_R] = {650, 300};
        position[SOLVE_RIDDLE] = {750, 300};
        position[SOLVE_RIDDLE2] = {850, 300};

        // names for a few section
        name[MENU] = "  Start";
        name[SECTION1] = "Section 1";
        name[SECTION2] = "Section 2";
        name[SECTION3] = "Section 3";
        name[BOSS_SECTION] = "  Boss";
        name[SECTION4] = "Section 4";
        
    }  

public:

    // map drawing
    // draw each nodes / section
    void drawNode(gameSection section){
        int x = position[section].first;
        int y = position[section].second;
  
        // draw the name of each section
        draw_text(name[section], COLOR_WHITE, x - 30, y - 5);
    }

    // drawing edge with nodes
    void drawEdge(gameSection start, gameSection end){
        int x1 = position[start].first;
        int y1 = position[start].second;
        int x2 = position[end].first;
        int y2 = position[end].second;

        // draw a line between the two nodes
        draw_line(COLOR_GREEN, x1, y1, x2, y2);
    }

    // draw the entier map
    void drawMap(){
        for(auto& start : graph) {
            for (auto& end : start.second){
                drawEdge(start.first, end);
            }
        }
        for(auto& section : position) {
            drawNode(section.first);
        }
    }

    // music
    void fantasyMusic(){
        load_music("fantasyMusic", "fantasyMusic.mp3");
        play_music("fantasyMusic", -1);
        refresh_screen();
    }

    // restart game
    void restartGame(){
        player.mana = 100;
        player.health = 100;
        game_section = MENU;
        orcFight = NONE_ACTION;
        healthPuzzle = NONE_ACTION_HEALTH;
        manaPuzzle = NONE_ACTION_MANA;
        skeletonLich = BEFORE_ACTION;
        riddleQ1 = NO_ANSWER;
        riddleQ2 = NO_ANSWER2;
        tookDamage = false;
        usedMana = false;
        gotHealth = false;
        gotMana = false;
        visitedSection.clear();
    }

    // section 2 and 3 return
    void sectionReturn(){
        game_section = MENU;
        orcFight = NONE_ACTION;
        healthPuzzle = NONE_ACTION_HEALTH;
        manaPuzzle = NONE_ACTION_MANA;
        skeletonLich = BEFORE_ACTION;
        riddleQ1 = NO_ANSWER;
        riddleQ2 = NO_ANSWER2;
        tookDamage = false;
        usedMana = false;
        gotHealth = false;
        gotMana = false;
        refresh_screen();
        delay(3000);  
    }

    // taking care of player health and mana
    void minusHealth(int amount){
        if(!tookDamage){
            player.health -= amount;
            tookDamage = true;
        }
    }
    void minusMana(int amount){
        if(!usedMana){
            player.mana -= amount;
            usedMana = true;
        }
    }
    void gainHealth(int amount){
        if(!gotHealth){
            player.health += amount;
            gotHealth = true;
        }
    }
    void gainMana(int amount){
        if(!gotMana){
            player.mana += amount;
            gotMana = true;
        }   
    }
    void resetTookDamage(){
        tookDamage = false;
    }
    void resetUsedMana(){
        usedMana = false;
    }
    void resetGotHealth(){
         gotHealth = false;
    }
    void resetGotMana(){
         gotMana = false;
    }

    TextRPG(){
        player.mana = 100;
        player.health = 100;
        game_section = MENU;
        orcFight = NONE_ACTION;
        healthPuzzle = NONE_ACTION_HEALTH;
        manaPuzzle = NONE_ACTION_MANA;
        skeletonLich = BEFORE_ACTION;
        riddleQ1 = NO_ANSWER;
        tookDamage = false;
        usedMana = false;
        gotHealth = false;
        gotMana = false;
        gameGraph();

        // images
        load_bitmap("dnd", "dnd.png");
        load_bitmap("orc", "orc.jpg");
        load_bitmap("cave", "cave.jpg");
        load_bitmap("door", "door.jpg");
        load_bitmap("lich", "lich.jpg");
        load_bitmap("treasure", "treasure.jpg");
        fantasyMusic();
    }

    // Move to other section, need better understanding
    void moveToSection(gameSection nextSection) {
        if(find(graph[game_section].begin(), graph[game_section].end(), nextSection) != graph[game_section].end()) {
            game_section = nextSection;
        } 
    }

    void run(){
        open_window("Text RPG", 900, 650);
        stringstream current_input;
        string user_input;

        
        do{
            clear_screen(COLOR_BLACK);

            // restart game when player health or mana =< 0
            if (player.health <= 0 || player.mana <= 0){
                if(game_section == FAILED){
                    delay(3000);  
                    restartGame();
                }
                else {
                    draw_text("Your health or mana is 0, you died. The game will restart.", COLOR_WHITE, 10, 10);
                    refresh_screen();
                    delay(3000);  
                    restartGame();
                }
            }

            //Close window
            if (key_typed(ESCAPE_KEY)){
                close_window("Text RPG");
            }

            // handle backspace key
            if (key_typed(BACKSPACE_KEY)) {
                if (!current_input.str().empty()) {
                    string str = current_input.str();
                    str.pop_back();
                    current_input.str("");
                    current_input << str;
                }
            } 

            if (key_typed(R_KEY)){
                restartGame();
            }

            // handle enter key
            else if (key_typed(RETURN_KEY)) {
                user_input = current_input.str();

                // game menu
                if(game_section == MENU){
                    if(user_input == "1" && visitedSection.find(SECTION1) == visitedSection.end()) { // check if ‘SECTION1’ is in ‘visitedSection’
                        moveToSection(SECTION1); 
                    } 
                    else if(user_input == "2") {
                        moveToSection(SECTION2); 
                    }
                    else if(user_input == "3") {
                        moveToSection(SECTION3); 
                    }
                    else if(user_input == "4") {
                        moveToSection(SECTION4); 
                    }
                }

                // section 1
                else if(game_section == SECTION1){
                    if (user_input == "1") {
                        resetTookDamage();
                        resetUsedMana();
                        moveToSection(FAILED);
                    }
                    if (user_input == "2") {
                        resetTookDamage();
                        resetUsedMana();
                        moveToSection(FIGHTING_ORC1);
                    }
                }
                else if(game_section == FIGHTING_ORC1){
                    if(user_input == "1"){
                        resetTookDamage();
                        resetUsedMana();
                        orcFight = POWERFUL_SPELL;
                    }
                }

                // section 2
                else if(game_section == SECTION2){ 
                    if(user_input == "1"){
                        moveToSection(SOLVE_HPUZZLE);
                    }
                    else if(user_input == "2"){
                        moveToSection(RETURNING_H);
                    }
                }
                else if(game_section == SOLVE_HPUZZLE){
                    if(user_input == "1"){
                        resetTookDamage();
                        minusHealth(10);
                    }
                    if(user_input == "2"){
                        resetGotHealth();
                        gainHealth(50);
                        healthPuzzle = CHOICE2;
                    } 
                    if(user_input == "3"){
                        resetTookDamage();
                        minusHealth(10);
                    }  
                }

                // section 3
                else if(game_section == SECTION3){
                    if(user_input == "1"){
                        moveToSection(SOLVE_MPUZZLE);
                    }
                    else if(user_input == "2"){
                        moveToSection(RETURNING_M);
                    }
                }
                else if(game_section == SOLVE_MPUZZLE){
                    if(user_input == "1"){
                        resetUsedMana();
                        minusMana(10);
                    }
                    if(user_input == "2"){
                        resetGotMana();
                        gainMana(50);
                        manaPuzzle = CHOICE_2;
                    } 
                    if(user_input == "3"){
                        resetUsedMana();
                        minusMana(10);
                    } 
                }
            
                else if(game_section == BOSS_SECTION){
                    if(user_input == "1"){
                        resetTookDamage();
                        resetUsedMana();
                        minusMana(70);
                        minusHealth(40);
                        moveToSection(FIRST_HIT);
                    }
                }
                else if(game_section == FIRST_HIT){
                    if(user_input == "1"){
                        resetTookDamage();
                        resetUsedMana();
                        minusHealth(40);
                        minusMana(70);
                        skeletonLich = BEST_SPELL;
                    }
                }

                // section 4
                else if(game_section == SECTION4){
                    if(user_input == "1"){
                        moveToSection(SOLVE_RIDDLE);
                    }
                    else if(user_input == "2"){
                        moveToSection(RETURNING_R);
                    }
                }
                else if(game_section == SOLVE_RIDDLE){
                    if(user_input == "candle"){
                        resetGotHealth();
                        resetGotMana();
                        gainHealth(50);
                        gainMana(50);
                        riddleQ1 = CORRECT_ANSWER;
                    }
                    else{
                        resetTookDamage();
                        resetUsedMana();
                        minusMana(100);
                        minusHealth(100);
                    }
                }
                else if(game_section == SOLVE_RIDDLE2){
                    if(user_input == "bank"){
                        resetGotHealth();
                        resetGotMana();
                        gainHealth(80);
                        gainMana(80);
                        riddleQ2 = CORRECT_ANSWER2;
                    }
                    else{
                        resetTookDamage();
                        resetUsedMana();
                        minusMana(100);
                        minusHealth(100);
                    }
                }



                current_input.str("");
                current_input.clear();
            } 
            else {
                // allow player to type from 0 to 9
                for(char i = '0'; i <= '9'; ++i) {
                    if(key_typed(static_cast<key_code>(i))) {
                        current_input << i;
                        break;
                    }
                }

                // allow player to type a to z
                for(char i = 'a'; i <= 'z'; i++){
                    if(key_typed(static_cast<key_code>(i))) {
                        current_input << i;
                        break;
                    }
                }
            }

            // control game in the game loop

            // section 1
            if(game_section == MENU){
                draw_bitmap("dnd", -1500,-500, option_scale_bmp(0.05,0.05));
                drawMap();
                draw_text("Welcome young adventurer to an adventure in another world!", COLOR_WHITE, 10, 30);
                draw_text("You are in a cave with 4 sections. Type 1, 2, 3, 4 to choose where you want to go.", COLOR_WHITE, 10, 50);
            }
            else if(game_section == SECTION1){
                visitedSection.insert(SECTION1); // insert ‘SECTION1’ to ‘visitedSection’ if the player enters ‘SECTION1’.
                draw_bitmap("orc", -280, -380, option_scale_bmp(0.3,0.3));
                draw_text("Upon entering section 1, an orc blocks your path. ", COLOR_WHITE, 10, 30);
                draw_text("Type '1' to cast a powerful spell or '2' to run while cast a weak spell", COLOR_WHITE, 10, 50);
            }
            else if(game_section == FAILED){
                draw_bitmap("orc", -280, -380, option_scale_bmp(0.3,0.3));
                draw_text("You cast a powerful spell. It dealt some damange, but ultimately, the orc got you.", COLOR_WHITE, 10, 30);
                minusMana(50);
                minusHealth(100);
            }
            else if(game_section == FIGHTING_ORC1){
                if(orcFight == NONE_ACTION){
                    minusHealth(25);
                    minusMana(25);
                    draw_bitmap("orc", -280, -380, option_scale_bmp(0.3,0.3));
                    draw_text("You decide to run away, casting a weak spell to cover your escape. The orc manages to hit you, but you are ", COLOR_WHITE, 10, 30);
                    draw_text("still alive. After casting the spell, you keep on running until you reach a dead end. With your back facing", COLOR_WHITE, 10, 50);
                    draw_text("a wall, you cast a powerful spell in hopes of killing the orc. Type '1' to cast the spell", COLOR_WHITE, 10, 70);

                }
                else if(orcFight == POWERFUL_SPELL){
                    draw_text("You have finally managed to kill the orc. Now it's time to head back to the crossroad.", COLOR_WHITE, 10, 10);
                    minusMana(50);
                    sectionReturn();
                }
            }
            
            // section 2
            else if(game_section == SECTION2){
                draw_bitmap("door", 160, 183, option_scale_bmp(1.2,1.2));
                draw_text("Upon entering section 2, you notice that there is a puzzle to be solved in order to advance.", COLOR_WHITE, 10, 30);
                draw_text("Type '1' to solve or '2' to go back", COLOR_WHITE, 10, 50);
            }
            else if(game_section == RETURNING_H){
                draw_text("You are returning to the conjunction.", COLOR_WHITE, 10, 10);
                sectionReturn();
            }
            else if(game_section == SOLVE_HPUZZLE){
                if(healthPuzzle == NONE_ACTION_HEALTH){
                    draw_bitmap("door", 160, 183, option_scale_bmp(1.2,1.2));
                    draw_text("There is a hole in the wall and 3 keys are presented. If you choose the right key, you will be rewarded,", COLOR_WHITE, 10, 30);
                    draw_text("but if you choose the wrong key, you will be punished. Type '1' or '2' or '3' to choose.", COLOR_WHITE, 10, 50);
                }
                else if(healthPuzzle == CHOICE2){
                    game_section = BOSS_SECTION;
                }
            }

            // section 3
            else if(game_section == SECTION3){
                draw_bitmap("door", 160, 183, option_scale_bmp(1.2,1.2));
                draw_text("Upon entering section 3, you notice that there is a puzzle to be solved in order to advance.", COLOR_WHITE, 10, 30);
                draw_text("Type '1' to solve or '2' to go back.", COLOR_WHITE, 10, 50);
            }
            else if(game_section == RETURNING_M){
                draw_text("You are returning to the conjunction.", COLOR_WHITE, 10, 10);
                sectionReturn();
            }
            else if(game_section == SOLVE_MPUZZLE){
                if(manaPuzzle == NONE_ACTION_MANA){
                    draw_bitmap("door", 160, 183, option_scale_bmp(1.2,1.2));
                    draw_text("There is a hole in the wall and 3 keys are presented. If you choose the right key, you will be rewarded,", COLOR_WHITE, 10, 30);
                    draw_text("but if you choose the wrong key, you will be punished. Type '1' or '2' or '3' to choose.", COLOR_WHITE, 10, 50);
                }
                else if(manaPuzzle == CHOICE_2){
                    game_section = BOSS_SECTION;
                }
            }

            // final boss
            else if(game_section == BOSS_SECTION){
                draw_bitmap("lich", 80, -130, option_scale_bmp(0.6,0.5));
                draw_text("After entering the right key, you have recieved some boost in your stats. Upon entering, you are greeted a", COLOR_WHITE, 10, 30);
                draw_text("laugh from a skeleton sitting on a throne. It's a skeleton lich! You decide to cast your strongest spell. ", COLOR_WHITE, 10, 50);
                draw_text("Type '1' to cast.", COLOR_WHITE, 10, 70);
            }
            else if(game_section == FIRST_HIT){
                if(skeletonLich == BEFORE_ACTION){
                    draw_bitmap("lich", 80, -130, option_scale_bmp(0.6,0.5));
                    draw_text("You have casted your strongest spell against the lich, but it still alive and cast back at you.", COLOR_WHITE, 10, 30);
                    draw_text("You would need to cast another spell of that calibre. Type '1' to cast.", COLOR_WHITE, 10, 50);
                }
                else if(skeletonLich == BEST_SPELL){
                    draw_bitmap("treasure", 150, 200, option_scale_bmp(1.2,1.2));
                    draw_text("Your spell devours the lich and present in front of you is a treasure trest that it has been guarding.", COLOR_WHITE, 10, 30);
                    draw_text("Nervously, you open the chest and find legendary relics. You claim them all and that wraps up for this", COLOR_WHITE, 10, 50);
                    draw_text("adventure RPG. Hope you enjoy the ride. You can press 'R' restart or 'ESC' to leave the game", COLOR_WHITE, 10, 70);
                }
            }

            // section 4
            else if(game_section == SECTION4){
                draw_text("Upon entering section 4, you notice on the wall is a list of word puzzles you would need to answer.", COLOR_WHITE, 10, 30);
                draw_text("You will gain many things if all of the questions are correctly answered, but failing to answer ", COLOR_WHITE, 10, 50);
                draw_text("one will result on your immediate death. Type '1' to solve and '2' to return.", COLOR_WHITE, 10, 70);
            }
            else if(game_section == RETURNING_R){
                draw_text("You are returning to the conjunction.", COLOR_WHITE, 10, 10);
                sectionReturn();
            }
            else if(game_section == SOLVE_RIDDLE){
                if(riddleQ1 == NO_ANSWER){
                    draw_text("I'm tall when I'm young, and I'm short when I'm old. What am I?", COLOR_WHITE, 10, 30);
                    draw_text("Type one word only.", COLOR_WHITE, 10, 50);
                }
                else if(riddleQ1 == CORRECT_ANSWER){
                    game_section = SOLVE_RIDDLE2;
                }
            }
            else if(game_section == SOLVE_RIDDLE2){
                if(riddleQ2 == NO_ANSWER2){
                    draw_text("I have branches, but no fruit, trunk or leaves. What am I?", COLOR_WHITE, 10, 30);
                    draw_text("Type one word only.", COLOR_WHITE, 10, 50);
                }
                else if(riddleQ2 == CORRECT_ANSWER2){
                    game_section = BOSS_SECTION;
                }
            }



            // user's input
            draw_text("Your Input: " + current_input.str(), COLOR_WHITE, 10, 10);

            // display health and mana
            string displayHealth = "Health: " + to_string(player.health);
            string displayMana = "Mana: " + to_string(player.mana);
            draw_text(displayHealth, COLOR_WHITE, 720, 10);
            draw_text(displayMana, COLOR_WHITE, 820, 10);


            refresh_screen(60);
            process_events();
        }while (!window_close_requested("Text RPG"));
    }



};


int main(){
    TextRPG game;
    game.run();
    return 0;
}