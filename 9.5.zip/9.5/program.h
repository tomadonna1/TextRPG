#ifndef PROGRAM_H
#define PROGRAM_H

#include "splashkit.h"
#include <sstream>
#include <string>
#include <iostream>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
using namespace std;

// enums
enum gameSection{
    MENU,
    SECTION1, FAILED, FIGHTING_ORC1, 
    SECTION2, RETURNING_H, SOLVE_HPUZZLE,
    SECTION3, RETURNING_M, SOLVE_MPUZZLE,
    BOSS_SECTION, FIRST_HIT, BOSS_KILL,
    SECTION4, RETURNING_R, SOLVE_RIDDLE, SOLVE_RIDDLE2
};

enum OrcFight{
    NONE_ACTION,
    POWERFUL_SPELL
};

enum HealthPuzzle{
    NONE_ACTION_HEALTH,
    CHOICE2
};

enum ManaPuzzle{
    NONE_ACTION_MANA,
    CHOICE_2
};

enum SkeletonLich{
    BEFORE_ACTION,
    BEST_SPELL
};

enum RiddleQ1{
    NO_ANSWER,
    CORRECT_ANSWER
};

enum RiddleQ2{
    NO_ANSWER2,
    CORRECT_ANSWER2
};


// function declaration
void restartGame();
void sectionReturn();
void fantasyMusic();
void minusHealth(int amount);
void minusMana(int amount);
void gainHealth(int amount);
void gainMana(int amount);
void resetGotHealth();
void resetGotMana();
void resetUsedMana();
void resetTookDamage();
void gameGraph();



#endif