//
// SplashKit Generated Input C++ Code
// DO NOT MODIFY
//

#ifndef __input_h
#define __input_h

#include <string>
#include <vector>
using std::string;
using std::vector;

void process_events();
bool quit_requested();
void reset_quit();

#endif /* __input_h */
